<?php
/**
 * This file was used to test if local machne has php - mongodb drivers.
 */
phpinfo();

