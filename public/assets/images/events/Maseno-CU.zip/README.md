# Architecture used.
* We using the Model-View-Controller architecture.
# Things to note.
* All eveteams logo should be stored in the ev-logo directory of the  images directory locted in the assets.
the 

# The Project Directories.
* They are three; 
    - app
    - backend
    - public
* The index.php is at the root of the project - Where the project is launched from

# Image formats.
- Images used in building the front_end, such as logos are used in the jpg format.


##### Update the README.md file as development process goes on.




